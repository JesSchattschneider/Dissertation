measure_with_ruler <- function(pols, length, lonlat=FALSE) {
  #stopifnot(inherits(pols, 'SpatialPolygons'))
  #stopifnot(length(pols) == 1)
  # get the coordinates of the polygon
  g <- geom(pols)[, c('x', 'y')]
  nr <- nrow(g)
  # we start at the first point
  pts <- 1
  newpt <- 1
  while(TRUE) {
    # start here
    p <- newpt
    # order the points
    j <- p:(p+nr-1)
    j[j > nr] <- j[j > nr] - nr
    gg <- g[j,]
    # compute distances
    pd <- pointDistance(gg[1,], gg, lonlat)
    # get the first point that is past the end of the ruler
    # this is precise enough for our high resolution coastline
    i <- which(pd > length)[1]
    if (is.na(i)) {
      stop('Ruler is longer than the maximum distance found')
    }
    # get the record number for new point in the original order
    newpt <- i + p
    # stop if past the last point
    if (newpt >= nr) break
    pts <- c(pts, newpt)
  }
  # add the last (incomplete) stick.
  pts <- c(pts, 1)
  # return the locations
  g[pts, ]
}

angle_ind <- function(az){
  pp <- as.data.frame(az[i])
  xy <- pp[,c(1,2)]
  ruleshp <- SpatialPointsDataFrame(coords=xy, data=pp,
                                    proj4string=CRS("+init=epsg:5641"))
  #transform the raster based in the projection
  rule <- spTransform(ruleshp, CRS(prjwgs84))
  rule<-as.data.frame(rule)
  rule<-rule[,3:4]
  rule<-as.matrix(rule)
  azi<-as.data.frame(geosphere::bearing(rule))
  azi<-bind_cols(azi,pp)
  colnames(azi)<-c("azi","x","y")
  azi$AMT<-ifelse((azi$azi <= 90 & azi$azi >= 0) & (lag(azi$azi) >= -90 & lag(azi$azi) <= 0), abs(abs(azi$azi)+abs(lag(azi$azi))), #3
                  +ifelse((azi$azi >= 0) & (lag(azi$azi) >= 0), abs(azi$azi-lag(azi$azi)), #1
                          +ifelse((azi$azi <= 0) & (lag(azi$azi) <= 0), abs(azi$azi-lag(azi$azi)), #2
                                  +ifelse((azi$azi <=0 && azi$azi >= -90) & (lag(azi$azi) > 90), 180-(abs(azi$azi)), #4
                                          +ifelse((lag(azi$azi) <= -90) & (azi$azi > 90), (360-(abs(abs(lag(azi$azi))+abs(azi$azi)))), #5
                                                  +ifelse((lag(azi$azi) <= 90 & lag(azi$azi) >= 0) & (azi$azi >= -90 & azi$azi <= 0), abs(abs(azi$azi)+abs(lag(azi$azi))), #6
                                                          +ifelse((lag(azi$azi)) <= 0 & (lag(azi$azi) >= -90) & (azi$azi >= 90), ((180-abs(lag(azi$azi)))+(180-azi$azi)),
                                                                  +ifelse((azi$azi>=0 & azi$azi<90) & lag(azi$azi < -90), 360-(abs(azi$azi)+abs(lag(azi$azi))),
                                                                          +ifelse(((azi$azi < -90) & lag(azi$azi)>=0 & lag(azi$azi)<90), 360-(abs(azi$azi)+abs(lag(azi$azi))),1))))))))) #7
  azi
}

pts_sf <- function(pt,lc){
  lc <- lc
  pp <- as.data.frame(pt[i])
  pp <- st_as_sf(pp,coords = c(2,3))
  pp <- st_set_crs(pp,5641)
  #colnames(pp)<-c("azi","x","y")
  #extract multiple lc segments usign the point limit to cut##
  #find the points that touch
  nrst <- st_nearest_points(lc, pp)
  pp_lc <- st_cast(nrst, "POINT")
  pp_lc <- st_combine(pp_lc)
  #cut
  pp_lc = st_collection_extract(lwgeom::st_split(lc$geometry, pp_lc),"LINESTRING")
  #set sf
  pp_lc_sf = st_as_sf(data.frame(id = 1:length(pp_lc),geometry = pp_lc))
  #clean the lc adding to the segments only the info from the southest point##
  pp_sf <- st_buffer(pp, dist = 0.1)
  joined_one=st_join(pp_lc_sf, pp_sf)
  joined_one$id<-seq.int(nrow(joined_one))/2
  lcSeg<-joined_one[-(1:3),]
  #colnames(lc_) <- c("id","azi","scale","geometry")
  lcSeg<-lcSeg[ abs(lcSeg$id-round(lcSeg$id)) < 0.00000001, ]
  lcSeg
}
