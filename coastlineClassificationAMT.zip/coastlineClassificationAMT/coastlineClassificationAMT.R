## R code for:
## Capítulo II: Avaliação entre a complexidade morfológica da linha 
## de costa sul-sudeste brasileira com descritores de condicionantes costeiros locais

########################################################################################
#   Code developed by Jessica Leiria Schattschneider in Linux-GNU OS using R-3.5.3     #
#   Package versions used to built the code are indicated along it                     #
########################################################################################
## This is a reproducible code. The input data attached in the code paste.
## It reproduces the methological process used in "Capítulo II" to reach the
## quantitative shoreline classification as its comparative analysis with the 
## descriptors of the coastal environment
########################################################################################

##rm(list = ls())
### Libraries, functions and symbologies####
#libraries
library(factoextra) ## factoextra_1.0.5
library(raster) ## raster_2.8-19
library(rgdal) ## rgdal_1.4-3 
library(vegan) ## vegan_2.5-4 
library(devtools) ## devtools_2.0.2 
library(lwgeom) ## lwgeom_0.1-6 
library(sp) ## sp_1.3-1
library(rgeos) ## rgeos_0.4-2
library(sf) ## sf_0.7-3
library(mapview) ## mapview_2.6.3
library(reshape2) ## reshape2_1.4.3
library(tidyr) ## tidyr_0.8.3
library(tidyverse) ## tidyverse_1.2.1  
library(cluster) ## cluster_2.0.8
library(devtools) ## devtools_2.0.2
library(ggbiplot) ## ggbiplot_0.55 
library(geosphere) ## geosphere_1.5-7
library(dplyr) ## dplyr_0.8.0.1
library(spatstat) ## spatstat_1.59-0
library(GGally) ## GGally_1.4.0
library(ggfortify) ## ggfortify_0.4.6
library(data.table) ## data.table_1.12.2     


## Local functions
source("./20190610functions_atm.R")

## set symbology
library(RColorBrewer)
mapviewOptions(vector.palette = colorRampPalette(rev(brewer.pal(9, "RdYlGn"))),
               na.color = "magenta",
               layers.control.pos = "topright")



### Add the LC:####
lc <- st_read("./cropped_lc_clean.shp")
#plot(lc)
## Call the DATUM:
prjnew <-"+init=epsg:5641" # WGS 84
## Define it to the shp: 
lc_shp <- readOGR("./cropped_lc_clean.shp")
lc_shp <- spTransform(lc_shp, CRS(prjnew))


## Create the S dataset##
y <- list()
#rulers <- c(15,25,30,40,50,60,70,80,90) # km
rulers <- c(0.5,1.0,2.0,2.5,3.0,4.0,5.0,10,15) # km
for (i in 1:length(rulers)) {
  y[[i]] <- measure_with_ruler(lc_shp, rulers[i]*1000)
}

##### Calculate the azimuth #####
##create a WGS84 frame 
prjwgs84 <-"+init=epsg:4326" # WGS 84
# get a list of results:
p <- list()
for (i in 1:length(y)) {
  p[[i]] <- angle_ind(y)
}

##### Spatial Join####
# get a list of results:
pontos_sf <- list()
for (i in 1:length(p)) {
  pontos_sf[[i]] <- pts_sf(p,lc)
}
# view the result:
# mapview(pontos_sf[9],zcol="AMT")

##### Preprocess the AMT individual results, aggregate them and clean the workspace####

#name the list
names(pontos_sf) <- paste("scale", 1:9, sep = "")
#save lists as different dataframes and merge in one single dataframe
for (i in 1:length(pontos_sf)) {
  assign(paste0("scales", i), pontos_sf[[i]])
}

scales1$scale<-"scale 0.5"
scales2$scale<-"scale 1"
scales3$scale<-"scale 2"
scales4$scale<-"scale 2.5"
scales5$scale<-"scale 3"
scales6$scale<-"scale 4"
scales7$scale<-"scale 5"
scales8$scale<-"scale 10"
scales9$scale<-"scale 15"

## Fill the nan observations
scales1$AMT[scales1$id==2] <- scales1$AMT[scales1$id==3]
scales2$AMT[scales2$id==2] <- scales2$AMT[scales2$id==3]
scales3$AMT[scales3$id==2] <- scales3$AMT[scales3$id==3]
scales4$AMT[scales4$id==2] <- scales4$AMT[scales4$id==3]
scales5$AMT[scales5$id==2] <- scales5$AMT[scales5$id==3]
scales6$AMT[scales6$id==2] <- scales6$AMT[scales6$id==3]
scales7$AMT[scales7$id==2] <- scales7$AMT[scales7$id==3]
scales8$AMT[scales8$id==2] <- scales8$AMT[scales8$id==3]
scales9$AMT[scales9$id==2] <- scales9$AMT[scales9$id==3]
## Join the LCs
join_lc=st_join(scales1,scales2,largest=TRUE)
join_lc=st_join(join_lc,scales3,largest=TRUE)
join_lc=st_join(join_lc,scales4,largest=TRUE)
join_lc=st_join(join_lc,scales5,largest=TRUE)
join_lc=st_join(join_lc,scales6,largest=TRUE)
join_lc=st_join(join_lc,scales7,largest=TRUE)
join_lc=st_join(join_lc,scales8,largest=TRUE)
join_lc=st_join(join_lc,scales9,all.y=TRUE,largest=TRUE)

## if you prefer to save yours and use it for the next steps uncomment
## the following line:

## join_lc<-st_write("./join_lc_shp.shp")

## DROP ALL YOUR WORKSPACE!!:
rm(list=ls())

###############################################################################
## Add just the essential dataframe and shps:####

join_lc<-st_read("./join_lc.shp")
## if you want to use the df you just created uncomment the following line:
## join_lc<-st_read("./join_lc_shp.shp") 

pp90<-st_read("./endpoint.shp" )

###############################################################################
## Reaching Complexity Groups (cluster) - AMT ####
## Start the cluster analysis
cp_90<-aggregate(join_lc[, c(3,7,11,15,19,23,27,31,35)], list(join_lc$id), sd)
cp_90<-`st_geometry<-`(cp_90, NULL)
cp_90<-cp_90[,-10]
colnames(cp_90) <- c("sector","0.5","1.0","2.0","2.5","3.0","4.0","5.0","10")

## HClust:
d   <- dist(scale(cp_90[complete.cases(cp_90), 2:9]), method="euclidean")
fit <- hclust(d, method="ward.D")
plot_hward<-plot(fit)
teste<-cp_90[complete.cases(cp_90), 1:9]
groups <- as.data.frame(cutree(fit, k = 4)) 
teste$cluster4<-groups$`cutree(fit, k = 4)`

## Plotar resultado
lcCluster<-teste
ATM_15km_geom<-scales9[,-c(2:3,5)]
lcCluster <- merge(ATM_15km_geom, lcCluster, by.x="id", by.y="sector", all=TRUE)
#colnames(lcCluster) <- c("id","15","0.5","1.0","2.0","2.5","3.0","4.0","5.0","10","cluster","geometry")
lcCluster$cluster4[lcCluster$id==20] <- 4
mapview(lcCluster, zcol="cluster4")

## seeking to use the same group order of the article, import the original shp:
lcCluster<-st_read("./lcClusterWardD.shp")
colnames(lcCluster) <- c("id","0.5","1.0","2.0","2.5","3.0","4.0","5.0","10","cluster4","geometry")
lcCluster<-`st_geometry<-`(lcCluster, NULL)

##Plot the difference btw cluster groups
cp_90_m<-lcCluster
cp_90_m$cluster4<-paste0("Grupo 0",cp_90_m$cluster4)

##Plot boxplot
cp_90_m<-melt(cp_90_m, id.vars = c("id","cluster4"), measure.vars = 2:9)
boxp =ggplot(cp_90_m, aes(x=variable, y=value)) + geom_boxplot()+ facet_wrap(~cluster4)

boxp=boxp+
  theme(strip.text.x = element_text(size = 12))+
  labs(x = "Comprimentos escalares - S (km)", y = "Variabilidade de Cx (σCx)")

## Save the boxplot 
ggsave(boxp, filename = "./boxp.png",width = 20, height = 15, units = "cm")

###############################################################################
## Prepare for Env Analysis, call input data and define projection:####
class_90km<-lcCluster
grid_falhas <- st_read("./gridStrokeConc15km.shp")
falhas <- st_read("./clip_geral.shp")
lito<- st_read("./litologia_5641.shp")
bat<-st_read("./pointsResultBat.shp")
srtm_base<-st_read("./pointsResultSRTM.shp")

grid_falhas %>% st_set_crs(st_crs(5641))
lito %>% st_set_crs(st_crs(5641))
lc%>% st_set_crs(st_crs(5641))
class_90km%>% st_set_crs(st_crs(5641))

###############################################################################
## LITOLOGY DIVERSITY DESCRIPTOR:####
###create buffer and mask for lc (continental coastal zone)
teste<-st_cast(class_90km, "MULTILINESTRING")
teste_<-st_simplify(teste, preserveTopology = TRUE, dTolerance = 1000)
lc_buffer<-st_buffer(teste_, 5000, endCapStyle = "FLAT")
mask <- lc_buffer  %>%st_union

##lito buffer to remove spaces:
lito_buff<-st_buffer(lito,0.1)
#create a mask for lito to remove the islands
lito_buf<-lito_buff %>% st_union
lito_buf<-st_sf(lito_buf)
lito_disag<-st_cast(lito_buf, "POLYGON")
lito_disag$area<-st_area(lito_disag)
lito_disag$area<-as.numeric(lito_disag$area)
#select the two biggest compartments:
i <- c(18,220)
tt <- lito_disag[i,]
#define CRS for the new data
lito_buff %>% st_set_crs(st_crs(5641))
tt %>% st_set_crs(st_crs(5641))

#cut the lito based in the mask without the islands
pi <- st_intersection(lito_buff, tt)
#st_write(pi,"./litoclean.shp")

#Obtain the five 5km buffer for lito and associate with corresponding segment:
lc_10km_lito<-st_intersection(pi,lc_buffer)
lc_10km_lito %>% st_set_crs(st_crs(5641))
# save the result:
st_write(lc_10km_lito,"./lito_segment_shp.shp",update=TRUE)

# uncomment the following lines if you want to use the result obtained by the article
# lc_10km_lito<-st_read("./lito_segment.shp")

## visualization:
mapview(lc_10km_lito, zcol="classe_roc")+class_90km
lito_clean<-na.omit(lc_10km_lito[,c(1,3,7)])
lito_clean$area=as.numeric(st_area(lito_clean$geometry))
teste <- ddply(lito_clean, c("id_1","classe_roc"), summarise, sum_classe_id=sum(area))
lito_shannon<-spread(teste,classe_roc,sum_classe_id)

##Substitute NA for 0:
lito_shannon$`Material superficial`<-lito_shannon$`Material superficial`%>% replace_na(0)
lito_shannon$`Material superficial, Sedimentar`<-lito_shannon$`Material superficial, Sedimentar` %>% replace_na(0)
lito_shannon$Metamórfica<-lito_shannon$Metamórfica %>% replace_na(0)
lito_shannon$Sedimentar<-lito_shannon$Sedimentar %>% replace_na(0)
lito_shannon$Ígnea<-lito_shannon$Ígnea %>% replace_na(0)

#Calculate Shannon:
shannon_div<-as.data.frame(diversity(lito_shannon[-1], index="shannon"))
shannon_div<-cbind(lito_shannon,shannon_div)
shannon_div<-shannon_div[,c(1,7)]
colnames(shannon_div) <- c("id","shannon")

## STROKE CONCENTRATION DESCRIPTOR:####
##Join the stroke count information with the LC segments
joined_grid=st_join(grid_falhas, class_90km)
joined_grid<-joined_grid[,(3:4)]
joined_grid<-na.omit(joined_grid)

#Calculate the mean of grid count by segment
strokeConcentration<-aggregate(joined_grid[, 1], list(joined_grid$id), mean)
colnames(strokeConcentration) <- c("id","strokeConcentration","geometry")
strokeConcentration<-`st_geometry<-`(strokeConcentration, NULL)

## Merge the last Env Descriptors to morphological classification
lcClassEnvData<-merge(class_90km, shannon_div, by="id",all.x=TRUE)
lcClassEnvData<-merge(lcClassEnvData,strokeConcentration, by="id", all.x=TRUE)

# Set some data specifications:
lcClassEnvData_df<-`st_geometry<-`(lcClassEnvData, NULL)
lcClassEnvData_df$cluster4<-as.factor(lcClassEnvData_df$cluster4)
lcClassEnvData_df$shannon<-lcClassEnvData_df$shannon %>% replace_na(0)
lcClassEnvData_df$strokeConcentration<-lcClassEnvData_df$strokeConcentration %>% replace_na(0)

## BATHIMETRIC SLOPE DESCRIPTOR ####
# Batimetria
bat<-bat[,-c(1,3:6)]
bat<-na.omit(bat)
bat$rvalue_1[bat$rvalue_1==-5.0000000] <- 0
bat<-setDT(bat)[,.(bat=coef(lm(rvalue_1 ~ distance))["distance"]),by="id"]
pts<-`st_geometry<-`(bat, NULL)
## Merge with lcClassEnvData
batimetria<-merge(pts, lcClassEnvData, by="id",all.x=TRUE)
ptsg<- batimetria %>% group_by(cluster4)
#
ptsg$cluster4<-paste0("Grupo 0",ptsg$cluster4)
ptsg$distance<-ptsg$distance/1000
#
v=
  ggplot(data = ptsg, mapping = aes(x = distance, y = -1*(rvalue_1), color =(id))) +
  geom_line() +
  facet_wrap(~cluster4 ~ .)

v=
  v+
  scale_color_continuous(name  ="Segmentos")+
  stat_smooth(se=F, color="black",size=0.5)+
  theme(strip.text.x = element_text(size = 12))+
  labs(x = "Distância da linha de costa (km)", y = "Elevação (m)")

ggsave(v, filename = "./batimetria_perfil.png",width = 20, height = 15, units = "cm")
# `geom_smooth()` using method = 'gam' and formula 'y ~ s(x, bs = "cs")'

## ALTIMETRIC SLOPE DESCRIPTOR ####
srtm<-srtm_base[,-c(2:4,6)]
srtm<-na.omit(srtm)
srtm<-setDT(srtm)[,.(srtm=coef(lm(rvalue_1 ~ distance))["distance"]),by="id"]
pts1<-`st_geometry<-`(na.omit(srtm_base), NULL)
##fazer merge com o pts e o lcClassEnvData
srtm_profile<-merge(pts1, lcClassEnvData, by="id",all.x=TRUE)
ptsg1<- srtm_profile %>% group_by(cluster4)
#
ptsg1$cluster4<-paste0("Grupo 0",ptsg1$cluster4)
ptsg1$distance<-ptsg1$distance/1000

p=
  ggplot(data = ptsg1, mapping = aes(x = -1*distance, y = rvalue_1, color =(id))) +
  geom_line() +
  facet_wrap(~cluster4 ~ .)
p=p+
scale_colour_gradientn(name  ="Segmentos",colours = terrain.colors(156))+
  stat_smooth(se=F, color="black",size=0.5)+
theme(strip.text.x = element_text(size = 12))+
labs(x = "Distância da linha de costa (km)", y = "Elevação (m)")
## save
ggsave(p, filename = "./elevação_perfil.png",width = 20, height = 15, units = "cm")
#`geom_smooth()` using method = 'loess' and formula 'y ~ x'

#############################################
## Data Investigation and final analysis:####
# Set data specifications and fix some missing data
lcClassEnvData_df_all<-merge(lcClassEnvData_df,bat,all.x=TRUE)
lcClassEnvData_df_all<-merge(lcClassEnvData_df_all,srtm,all.x=TRUE)
#
lcClassEnvData_df_all$strokeConcentration<-lcClassEnvData_df_all$strokeConcentration%>%replace_na(0)
lcClassEnvData_df_all$shannon<-lcClassEnvData_df_all$shannon%>%replace_na(0)
lcClassEnvData_df_all$bat[lcClassEnvData_df_all$id==20] <- 0.0013724013
lcClassEnvData_df_all$srtm[lcClassEnvData_df_all$id==20] <- -1.172527e-02

## subset:
tt<-lcClassEnvData_df_all[,c(1,10,11:14)]
colnames(tt) <- c("id","Grupo","Div.Geol.","Conc. Falhas", "Decliv. Imersa","Decliv. Emersa")

## Data distribution:
p <- ggpairs(na.omit(tt[,-c(1)]), aes(color = as.factor(Grupo)))+
  theme(strip.text.x = element_text(size = 12), strip.text.y = element_text(size = 12))
# Change color manually.
# Loop through each plot changing relevant scales
for(i in 1:p$nrow) {
  for(j in 1:p$ncol){
    p[i,j] <- p[i,j] + 
      scale_color_brewer(palette = "RdYlGn", direction=-1)+
      scale_fill_brewer(palette = "RdYlGn",  direction=-1)
  }
}
p

ggpairs.image<-p
# Save:
ggsave(ggpairs.image, filename = "./ggpairs.image.png",width = 20, height = 20, units = "cm")

## PCA:
res.pca<-prcomp(tt[,c(3:6)], center = TRUE,scale. = TRUE)

pca.image<-fviz_pca_biplot(res.pca, label="var",
                habillage = tt$Grupo, 
                palette = c('#336600','lightgreen','orange','red'),
                addEllipses = FALSE,  col.var = "black")

#save
ggsave(pca.image, filename = "./pca.image.png",width = 15, height = 12, units = "cm")

