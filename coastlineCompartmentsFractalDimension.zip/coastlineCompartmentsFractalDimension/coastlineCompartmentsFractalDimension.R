## R code for:
## Capítulo II: Caracterização Quantitativa da Complexidade Morfológica 
## da Linha de Costa Sul-Sudeste Brasileira por Métodos Fractais

########################################################################################
#   Code developed by Jessica Leiria Schattschneider in Linux-GNU OS using R-3.5.3     #
#   Package versions used to built the code are indicated along it                     #
########################################################################################
## This code reproduces the methological process used in "Capítulo I" to reach the
## quantitative shoreline characterization by the fractal dimension of
## four different compartments
########################################################################################

#rm(list = ls())
## Libraries and functions####
library(raster)
library(rgdal)
library(sf)
library(reshape)
library(dplyr)
library(plyr)
library(ggplot2)

## load shoreline shape:
lc_shp <- readOGR("./cropped_lc_clean_sectors.shp")

## STEP-DIVISOR METHOD ####
##set prj and devide in sectors##
id1<-subset(lc_shp, ID=="1")
id2<-subset(lc_shp, ID=="2")
id3<-subset(lc_shp, ID=="3")
id4<-subset(lc_shp, ID=="4")
#define prj:
prjnew <-"+init=epsg:5641" # WGS 84

#transform the raster based in the projection
lc_shp <- spTransform(lc_shp, CRS(prjnew))
id1 <- spTransform(id1, CRS(prjnew))
id2 <- spTransform(id2, CRS(prjnew))
id3 <- spTransform(id3, CRS(prjnew))
id4 <- spTransform(id4, CRS(prjnew))

measure_with_ruler <- function(pols, length, lonlat=FALSE) {
  #stopifnot(inherits(pols, 'SpatialPolygons'))
  #stopifnot(length(pols) == 1)
  # get the coordinates of the polygon
  g <- geom(pols)[, c('x', 'y')]
  nr <- nrow(g)
  # we start at the first point
  pts <- 1
  newpt <- 1
  while(TRUE) {
    # start here
    p <- newpt
    # order the points
    j <- p:(p+nr-1)
    j[j > nr] <- j[j > nr] - nr
    gg <- g[j,]
    # compute distances
    pd <- pointDistance(gg[1,], gg, lonlat)
    # get the first point that is past the end of the ruler
    # this is precise enough for our high resolution coastline
    i <- which(pd > length)[1]
    if (is.na(i)) {
      stop('Ruler is longer than the maximum distance found')
    }
    # get the record number for new point in the original order
    newpt <- i + p
    # stop if past the last point
    if (newpt >= nr) break
    pts <- c(pts, newpt)
  }
  # add the last (incomplete) stick.
  pts <- c(pts, 1)
  # return the locations
  g[pts, ]
}

###IDgeneral:###
y <- list()
rulers <- c(15,25,30,40,50,60,70,80,90) # km
for (i in 1:length(rulers)) {
  y[[i]] <- measure_with_ruler(lc_shp, rulers[i]*1000)
}

# number of times a ruler was used
n <- sapply(y, nrow)
comp<-as.data.frame(cbind(rulers,n))
comp$n<-comp$n-2
# simple plot
#plot((comp$rulers), (comp$n))

##D pelo plot de log
slp_tot=lm(log(comp$n)~log(comp$rulers))
-1 * slp_tot$coefficients[2]

###ID1:##
y <- list()
rulers <- c(15,25,30,40,50,60,70,80,90) # km

for (i in 1:length(rulers)) {
  y[[i]] <- measure_with_ruler(id1, rulers[i]*1000)
}


# number of times a ruler was used
n <- sapply(y, nrow)
comp1<-as.data.frame(cbind(rulers,n))
comp1$n<-comp1$n-2

##D pelo plot de log
slp1=lm(log(comp1$n)~log(comp1$rulers))
#plot(log(n),log(rulers))
-1 * slp1$coefficients[2]
round(-1 * slp1$coefficients[2], digits = 2)

###ID2:##
y <- list()
rulers <- c(15,25,30,40,50,60,70,80,90) # km
for (i in 1:length(rulers)) {
  y[[i]] <- measure_with_ruler(id2, rulers[i]*1000)
}

# number of times a ruler was used
n <- sapply(y, nrow)
n

comp2<-as.data.frame(cbind(rulers,n))
comp2$n<-comp2$n-2
##D pelo plot de log
slp2=lm(log(comp2$n)~log(comp2$rulers))
#plot(rulers,n)
-1 * slp2$coefficients[2]
round(-1 * slp2$coefficients[2], digits = 2)

###ID3:###
y <- list()
rulers <- c(15,25,30,40,50,60,70,80,90) # km
for (i in 1:length(rulers)) {
  y[[i]] <- measure_with_ruler(id3, rulers[i]*1000)
}
n <- sapply(y, nrow)
n
comp3<-as.data.frame(cbind(rulers,n))
comp3$n<-comp3$n-2
##D pelo plot de log
slp3=lm(log(comp3$n)~log(comp3$rulers))
-1 * slp3$coefficients[2]
round(-1 * slp3$coefficients[2], digits = 2)

###ID4:###
y <- list()
rulers <- c(15,25,30,40,50,60,70,80,90) # km
for (i in 1:length(rulers)) {
  y[[i]] <- measure_with_ruler(id4, rulers[i]*1000)
}

names(y) <- paste("scale", 1:9, sep = "")

for (i in 1:length(y)) {
  assign(paste0("scales", i), as.data.frame(y[[i]]))
}

# number of times a ruler was used
n <- sapply(y, nrow)
n
comp4<-as.data.frame(cbind(rulers,n))
comp4$n<-comp4$n-2
##D pelo plot de log
slp4=lm(log(comp4$n)~log(comp4$rulers))
-1 * slp4$coefficients[2]
round(-1 * slp4$coefficients[2], digits = 2)

#define points 90###
pp90 <- as.data.frame(scales9)%>% 
  sf::st_as_sf(coords = c(1,2)) %>% 
  sf::st_set_crs(5641)
mapview(pp90)

# st_write(pp90,"/home/jessica/Desktop/pp90.shp")

##plot##
comp1$comp<-rep("CP-01", times=9)
comp1$d<-rep(-1 * slp1$coefficients[2], times=9)

comp2$comp<-rep("CP-02", times=9)
comp2$d<-rep(-1 * slp2$coefficients[2], times=9)

comp3$comp<-rep("CP-03", times=9)
comp3$d<-rep(-1 * slp3$coefficients[2], times=9)

comp4$comp<-rep("CP-04", times=9)
comp4$d<-rep(-1 * slp4$coefficients[2], times=9)

d_fractal<-rbind(comp1[1,3:4],comp2[1,3:4],comp3[1,3:4],comp4[1,3:4])
comp_all<-rbind(comp1,comp2,comp3,comp4)
comp_all<-comp_all[,1:3]
comp_all%>%spread("rulers","n")

library(mapview)
lc_shp$ID<-paste0("Comp",lc_shp$ID)
lc_shp<-left_join(lc_shp,comp_all,by = c("ID" = "comp"), all=FALSE)
lc_shp$rank <- NA

lc_shp$Level_of_Complexity <- rank(-(lc_shp$d))
library(RColorBrewer)
mapviewOptions(vector.palette = colorRampPalette((brewer.pal(4, "RdYlGn"))),
               na.color = "magenta",
               layers.control.pos = "topright")

mapview(lc_shp, zcol = "Level_of_Complexity")

st_write(comp_all,"./lc_dm.shp")

tiff("/home/jessica/Documentos/r_graphs/20190523_dm.tif",width=500, height=400)
p <- ggplot(data = remove_missing(comp_all,na.rm = TRUE), aes(x=log(rulers), y=log(n))) + 
  geom_line() + geom_point(size = 0.5)+ 
  geom_text(label=paste0(comp_all$rulers,"km"), nudge_x = 0.1, nudge_y = 0.3, 
            angle=45,size=3, check_overlap = T)+
  # stat_smooth(linetype = "dashed", colour="darkblue", size=0.5, method=loess)+
  facet_wrap(~comp, scales = "free_x")+
  ylab('log(N)')+xlab('log(r)')+ggtitle("Divisor de Passos")
p
dev.off()

## Checking the R-square
summary(slp1)
summary(slp2)
summary(slp3)
summary(slp4)



## BOXCOUNTING METHOD ####
## Slope Function:
slope  <-  function(y,x){
  if(all(is.na(x)))
    # if x is all missing, then lm will throw an error that we want to avoid
    return(NA)
  else
    return(coef(lm(y~x))[2])
}
## Open de attribute table resulted from the zonal calculation performed in QGIS:
bc_<-read.csv("./boxcounting.csv")
## define scale
m_bc<- bc[c(3,5:13)]
m_bc<-melt(m_bc,id="id_c")
m_bc$scale[m_bc$variable=='c90']<-90
m_bc$scale[m_bc$variable=='c80']<-80
m_bc$scale[m_bc$variable=='c70']<-70
m_bc$scale[m_bc$variable=='c60']<-60
m_bc$scale[m_bc$variable=='c50']<-50
m_bc$scale[m_bc$variable=='c40']<-40
m_bc$scale[m_bc$variable=='c30']<-30
m_bc$scale[m_bc$variable=='c25']<-25
m_bc$scale[m_bc$variable=='c15']<-15

## Calculate D value to each shoreline compartment

boxcounting<-ldply(models, coef)
m_bc$d<--1*as.numeric(boxcounting$`log(scale)`)

m_bc$comp[m_bc$id_c==1] <- as.character("CP-01")
m_bc$comp[m_bc$id_c==2] <- as.character("CP-02")
m_bc$comp[m_bc$id_c==3] <- as.character("CP-03")
m_bc$comp[m_bc$id_c==4] <- as.character("CP-04")


tiff("/home/jessica/Documentos/r_graphs/20190523_bc.tif",width=500, height=400)
t <- ggplot(m_bc, aes(x=log(scale), y=log(value))) + geom_line() + geom_point(size = 1.5)+
  geom_text(label=paste0(m_bc$scale,"km"), nudge_x = 0.1, nudge_y = 0.3, 
            angle=45,size=3, check_overlap = T)+
  # stat_smooth(linetype = "dashed", colour="darkred", size=0.5, method=loess)+
  facet_wrap(~comp, scales = "free_x")+
  ylab('log(N)')+xlab('log(l)')+ggtitle("Contagem de Caixas")
t
dev.off()